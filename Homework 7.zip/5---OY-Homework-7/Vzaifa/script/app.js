document.getElementById('playerForm').addEventListener('submit', function (event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let club = document.getElementById('club').value;

    let players = JSON.parse(localStorage.getItem('players')) || [];
    players.push({ name, club });
    localStorage.setItem('players', JSON.stringify(players));
    displayPlayers();
});

function displayPlayers() {
    let players = JSON.parse(localStorage.getItem('players')) || [];
    let playerList = document.getElementById('playerList');
    playerList.innerHTML = '';

    players.forEach(player => {
        let li = document.createElement('li');
        li.textContent = `Ism: ${player.name}, Klub: ${player.club}`;
        playerList.appendChild(li);
    });
}

function filterPlayers() {
    let filterValue = document.getElementById('clubFilter').value;
    let players = JSON.parse(localStorage.getItem('players')) || [];
    let filteredPlayers = players.filter(player => player.club === filterValue);

    let playerList = document.getElementById('playerList');
    playerList.innerHTML = '';

    filteredPlayers.forEach(player => {
        let li = document.createElement('li');
        li.textContent = `Ism: ${player.name}, Klub: ${player.club}`;
        playerList.appendChild(li);
    });
}

document.getElementById('transferForm').addEventListener('submit', function (event) {
    event.preventDefault();
    let name = document.getElementById('nameTransfer').value;
    let newClub = document.getElementById('newClub').value;

    let players = JSON.parse(localStorage.getItem('players')) || [];
    players.forEach(player => {
        if (player.name === name) {
            player.club = newClub;
        }
    });
    localStorage.setItem('players', JSON.stringify(players));
    displayPlayers();
});

displayPlayers();


